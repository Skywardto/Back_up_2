#include "behavior.h"

Behavior::Behavior() {
}

Behavior::~Behavior() {
}

